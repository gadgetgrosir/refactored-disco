<?php 

class Kategori extends CI_Controller{
	public function elektronik()
	{
		$data['elektronik'] = $this->model_kategori->data_elektronik()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('elektronik', $data);
		$this->load->view('templates/footer');
	}

	public function perkakas_rumahtangga()
	{
		$data['perkakas_rumahtangga'] = $this->model_kategori->data_perkakas_rumahtangga()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('perkakas_rumahtangga', $data);
		$this->load->view('templates/footer');
	}

	public function kamera_photografi()
	{
		$data['kamera_photografi'] = $this->model_kategori->data_kamera_photografi()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('kamera_photografi', $data);
		$this->load->view('templates/footer');
	}

	public function hobi_olahraga()
	{
		$data['hobi_olahraga'] = $this->model_kategori->data_hobi_olahraga()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('hobi_olahraga', $data);
		$this->load->view('templates/footer');
	}

	public function smarthphone_aksesoris()
	{
		$data['smarthphone_aksesoris'] = $this->model_kategori->data_smarthphone_aksesoris()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('smarthphone_aksesoris', $data);
		$this->load->view('templates/footer');
	}

	public function komputer_laptop()
	{
		$data['komputer_laptop'] = $this->model_kategori->data_komputer_laptop()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('komputer_laptop', $data);
		$this->load->view('templates/footer');
	}

	public function fashion()
	{
		$data['fashion'] = $this->model_kategori->data_fashion()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('fashion', $data);
		$this->load->view('templates/footer');
	}


}

 ?>