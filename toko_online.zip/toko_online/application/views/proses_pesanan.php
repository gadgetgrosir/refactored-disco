<div class="container-fluid">
	<div class="alert alert-success">
		<h1 class="text-center align-middle">Pesanan Anda Telah Berhasil diproses,Tunggu konfirmasi pembayaran</h1>
	</div>
</div>
</table>
	<a href="<?php echo base_url('welcome') ?>"><div class="btn btn-sm btn-primary ml-4">kembali</div></a>
