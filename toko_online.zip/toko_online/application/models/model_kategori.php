<?php 
	
class Model_kategori extends CI_Model{

	public function data_elektronik(){
		return $this->db->get_where("tb_barang", array('kategori' => 'elektronik'));
	}

	public function data_perkakas_rumahtangga(){
		return $this->db->get_where("tb_barang", array('kategori' => 'perkakas & rumah tangga'));
	}

	public function data_kamera_photografi(){
		return $this->db->get_where("tb_barang", array('kategori' => 'kamera & photografi'));
	}

	public function data_hobi_olahraga(){

		return $this->db->get_where("tb_barang", array('kategori' => 'hobi & olahraga'));

	}

	public function data_smarthphone_aksesoris(){

		return $this->db->get_where("tb_barang", array('kategori' => 'smarthphone & aksesoris'));

	}

	public function data_komputer_laptop(){

		return $this->db->get_where("tb_barang", array('kategori' => 'komputer & laptop'));

	}

	public function data_fashion(){

		return $this->db->get_where("tb_barang", array('kategori' => 'fashion'));

	}
	



}	
 ?>